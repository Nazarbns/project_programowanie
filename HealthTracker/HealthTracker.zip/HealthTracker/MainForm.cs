﻿using System;
using System.Data.SQLite;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace HealthTracker
{
    public partial class MainForm : Form
    {
        private readonly int UserId; // Теперь используется
        private Label labelWaga, labelCisnienie, labelPuls;
        private TextBox txtWaga, txtCisnienie, txtPuls;
        private Button btnZapisz, btnWyczysc, btnEksport, btnUsun, btnSearch;
        private ComboBox comboFilter;
        private DataGridView dataGridZdrowie;

        public MainForm(int userId)
        {
            InitializeComponent();
            this.UserId = userId;
            InitializeDatabase();
            InitializeUI();
            LoadDataFromDatabase(); // Загружаем данные пользователя
        }

        private void InitializeDatabase()
        {
            string dbPath = "health.db";
            string connectionString = $"Data Source={dbPath};Version=3;";

            if (!File.Exists(dbPath))
            {
                SQLiteConnection.CreateFile(dbPath);
            }

            using (SQLiteConnection conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string sqlUsers = @"CREATE TABLE IF NOT EXISTS Users (
                                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                                    Username TEXT UNIQUE,
                                    Password TEXT
                                );";
                new SQLiteCommand(sqlUsers, conn).ExecuteNonQuery();

                string sqlHealth = @"CREATE TABLE IF NOT EXISTS HealthData (
                                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                                    UserId INTEGER,
                                    Date TEXT,
                                    Weight REAL,
                                    Pressure TEXT,
                                    Pulse INTEGER,
                                    FOREIGN KEY(UserId) REFERENCES Users(Id)
                                );";
                new SQLiteCommand(sqlHealth, conn).ExecuteNonQuery();
            }
        }

        private void InitializeUI()
        {
            labelWaga = new Label { Text = "Waga (kg):", Location = new Point(20, 20), AutoSize = true };
            labelCisnienie = new Label { Text = "Ciśnienie (mmHg):", Location = new Point(20, 60), AutoSize = true };
            labelPuls = new Label { Text = "Puls (bpm):", Location = new Point(20, 100), AutoSize = true };

            txtWaga = new TextBox { Location = new Point(150, 20), Width = 100 };
            txtCisnienie = new TextBox { Location = new Point(150, 60), Width = 100 };
            txtPuls = new TextBox { Location = new Point(150, 100), Width = 100 };

            btnZapisz = new Button { Text = "Zapisz", Location = new Point(20, 150), Width = 100 };
            btnZapisz.Click += new EventHandler(BtnZapisz_Click);

            btnWyczysc = new Button { Text = "Wyczyść", Location = new Point(130, 150), Width = 100 };
            btnWyczysc.Click += new EventHandler(BtnWyczysc_Click);

            btnEksport = new Button { Text = "Eksportuj", Location = new Point(240, 150), Width = 100 };
            btnEksport.Click += new EventHandler(BtnEksport_Click);

            btnUsun = new Button { Text = "Usuń", Location = new Point(350, 150), Width = 100 };
            btnUsun.Click += new EventHandler(BtnUsun_Click);

            btnSearch = new Button { Text = "Szukaj", Location = new Point(460, 150), Width = 100 };
            btnSearch.Click += new EventHandler(BtnSearch_Click);

            comboFilter = new ComboBox { Location = new Point(580, 150), Width = 100 };
            comboFilter.Items.AddRange(new string[] { "Wszystko", "Waga > 70", "Ciśnienie > 120/80", "Puls > 80" });
            comboFilter.SelectedIndex = 0;
            comboFilter.SelectedIndexChanged += new EventHandler(ComboFilter_SelectedIndexChanged);

            dataGridZdrowie = new DataGridView { Location = new Point(20, 200), Size = new Size(750, 300), ColumnCount = 3 };
            dataGridZdrowie.Columns[0].Name = "Waga";
            dataGridZdrowie.Columns[1].Name = "Ciśnienie";
            dataGridZdrowie.Columns[2].Name = "Puls";

            this.Controls.Add(labelWaga);
            this.Controls.Add(txtWaga);
            this.Controls.Add(labelCisnienie);
            this.Controls.Add(txtCisnienie);
            this.Controls.Add(labelPuls);
            this.Controls.Add(txtPuls);
            this.Controls.Add(btnZapisz);
            this.Controls.Add(btnWyczysc);
            this.Controls.Add(btnEksport);
            this.Controls.Add(btnUsun);
            this.Controls.Add(btnSearch);
            this.Controls.Add(comboFilter);
            this.Controls.Add(dataGridZdrowie);
        }

        private void LoadDataFromDatabase()
        {
            string dbPath = "health.db";
            string connectionString = $"Data Source={dbPath};Version=3;";

            using (SQLiteConnection conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string sql = $"SELECT Weight, Pressure, Pulse FROM HealthData WHERE UserId = {UserId}";
                using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                using (SQLiteDataReader reader = cmd.ExecuteReader())
                {
                    dataGridZdrowie.Rows.Clear();
                    while (reader.Read())
                    {
                        dataGridZdrowie.Rows.Add(reader["Weight"], reader["Pressure"], reader["Pulse"]);
                    }
                }
            }
        }

        private void BtnZapisz_Click(object sender, EventArgs e)
        {
            string dbPath = "health.db";
            string connectionString = $"Data Source={dbPath};Version=3;";

            using (SQLiteConnection conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string sql = "INSERT INTO HealthData (UserId, Date, Weight, Pressure, Pulse) VALUES (@UserId, @Date, @Weight, @Pressure, @Pulse)";
                using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@UserId", UserId);
                    cmd.Parameters.AddWithValue("@Date", DateTime.Now.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@Weight", txtWaga.Text);
                    cmd.Parameters.AddWithValue("@Pressure", txtCisnienie.Text);
                    cmd.Parameters.AddWithValue("@Pulse", txtPuls.Text);
                    cmd.ExecuteNonQuery();
                }
            }
            LoadDataFromDatabase(); // Обновляем таблицу после сохранения
        }

        private void BtnWyczysc_Click(object sender, EventArgs e)
        {
            txtWaga.Text = "";
            txtCisnienie.Text = "";
            txtPuls.Text = "";
        }

        private void BtnEksport_Click(object sender, EventArgs e)
        {
            // Здесь можно добавить логику экспорта данных
        }

        private void BtnUsun_Click(object sender, EventArgs e)
        {
            if (dataGridZdrowie.SelectedRows.Count > 0)
            {
                string dbPath = "health.db";
                string connectionString = $"Data Source={dbPath};Version=3;";

                using (SQLiteConnection conn = new SQLiteConnection(connectionString))
                {
                    conn.Open();
                    string sql = "DELETE FROM HealthData WHERE UserId = @UserId";
                    using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@UserId", UserId);
                        cmd.ExecuteNonQuery();
                    }
                }
                LoadDataFromDatabase(); // Обновляем таблицу после удаления
            }
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            // Логика поиска данных
        }

        private void ComboFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Логика фильтрации данных
        }
    }
}
