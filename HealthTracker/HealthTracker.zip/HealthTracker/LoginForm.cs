﻿using System;
using System.Data.SQLite;
using System.Drawing;
using System.Windows.Forms;

namespace HealthTracker
{
    public partial class LoginForm : Form
    {
        public int LoggedInUserId { get; private set; }

        private TextBox txtUsername, txtPassword;
        private Button btnLogin, btnRegister;

        public LoginForm()
        {
            InitializeComponent();
            InitializeUI();
        }

        private void InitializeUI()
        {
            this.Text = "Logowanie";
            this.Size = new Size(300, 200);
            this.StartPosition = FormStartPosition.CenterScreen;

            Label lblUsername = new Label { Text = "Nazwa użytkownika:", Location = new Point(20, 20), AutoSize = true };
            txtUsername = new TextBox { Location = new Point(150, 20), Width = 100 };

            Label lblPassword = new Label { Text = "Hasło:", Location = new Point(20, 60), AutoSize = true };
            txtPassword = new TextBox { Location = new Point(150, 60), Width = 100, PasswordChar = '*' };

            btnLogin = new Button { Text = "Zaloguj", Location = new Point(20, 100), Width = 100 };
            btnLogin.Click += BtnLogin_Click;

            btnRegister = new Button { Text = "Rejestracja", Location = new Point(150, 100), Width = 100 };
            btnRegister.Click += BtnRegister_Click;

            this.Controls.Add(lblUsername);
            this.Controls.Add(txtUsername);
            this.Controls.Add(lblPassword);
            this.Controls.Add(txtPassword);
            this.Controls.Add(btnLogin);
            this.Controls.Add(btnRegister);
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Wprowadź nazwę użytkownika i hasło!", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SQLiteConnection conn = new SQLiteConnection("Data Source=health.db;Version=3;"))
            {
                conn.Open();
                string sql = "SELECT Id FROM Users WHERE Username = @username AND Password = @password";
                using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);
                    object result = cmd.ExecuteScalar();

                    if (result != null && int.TryParse(result.ToString(), out int userId))
                    {
                        LoggedInUserId = userId;
                        MessageBox.Show("Logowanie zakończone sukcesem!", "Sukces", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Nieprawidłowa nazwa użytkownika lub hasło!", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
        }


        private void BtnRegister_Click(object sender, EventArgs e)
        {
            RegisterForm registerForm = new RegisterForm();
            registerForm.ShowDialog();
        }
    }
}
